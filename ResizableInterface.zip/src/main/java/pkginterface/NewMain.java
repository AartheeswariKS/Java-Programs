package pkginterface;
interface Resizable
{
   public void Resize(int x);
}
class Rectangle implements Resizable 
{
    int x;
    int length;
    int breadth;
    @Override
    public void Resize(int x)
    {
        this.x=x;
    }
    Rectangle(int length, int breadth)
    {
        this.length=length;
        this.breadth=breadth;
    }
    int getArea()
    {
        return length*breadth;
    }
    int getPerimeter()
    {        
        return 2*(length+breadth);
    }
    int resizedArea()
    {
        
        return (length*breadth)*x;
    }
    int resizedPerimeter()
    {
        
        return 2*(length+breadth)*x;
    }
    
    
}
class Circle implements Resizable
{
    int x;
    double radius;
    @Override
    public void Resize(int x)
    {
        this.x=x;
     
    }
    Circle(int radius)
    {
        this.radius=radius;
    }
    double getArea()
    {
        
        return 3.14*radius*radius;
    }
    double getPerimeter()
    {
       
        return 2*3.14*radius;
    }
    double resizedArea()
    {
        return 3.14*radius*radius*x;
        
    }
    double resizedPerimeter()
    {
       
        return 2*3.14*radius*x;
        
    }
    
}
public class NewMain
{
    public static void main(String[] args)
    {
        Rectangle r =new Rectangle(10,5);
        System.out.println("Area of the Rectangle is :"+ r.getArea());
        System.out.println("Perimeter of the Rectangle is: "+r.getPerimeter());
        r.Resize(5);
        System.out.println("Area of the resized Rectangle is: "+r.resizedArea());
        System.out.println("Perimeter of the resized Rectangle is: "+r.resizedPerimeter());
        Circle c =new Circle(4);
        System.out.println("Area of the Circle is: "+c.getArea());
        System.out.println("Perimeter of the Circle is: "+c.getPerimeter());
        c.Resize(10);
        System.out.println("Area of the resized Circle is: "+ c.resizedArea());
        System.out.println("Perimeter of the resized Circle is: "+  c.resizedPerimeter());
       
    }
    
}

