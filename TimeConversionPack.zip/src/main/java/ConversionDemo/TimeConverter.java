package ConversionDemo;
public class TimeConverter 
{
    public double HrsToMins(double Hrs)
    {
        double Mins=0;
        Mins=Hrs*60;
        return Mins;
    }
    public double MinsToHrs(double Mins)
    {
        double Hrs=0;
        Hrs=Mins/60;
        return Hrs;
    }
    public double HrsToSecs(double Hrs)
    {
        double Secs=0;
        Secs=Hrs*3600;
        return Secs;
    }
    public double SecsToHrs(double Secs)
    {
        double Hrs=0;
        Hrs=Secs/3600;
        return Hrs;
    }
    
}
