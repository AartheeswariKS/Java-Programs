package Main;
import ConversionDemo.TimeConverter;
public class Time
{
    public static void main(String[] args)
    {
        TimeConverter t=new TimeConverter();
        System.out.println("Convert Hrs to Mins: "+t.HrsToMins(3));
        System.out.println("Convert Mins to Hrs: "+t.MinsToHrs(3));
        System.out.println("Convert Hrs to Secs: "+t.HrsToSecs(3));
        System.out.println("Convert Secs to Hrs: "+t.SecsToHrs(3600));
        
     
    }
    
}
