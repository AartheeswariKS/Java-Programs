class Shapes
{
    double Dimension;
    Shapes(double Dimension)
    {
      this.Dimension=Dimension;  
    }
}
class Circle extends Shapes
{
    double Radius=Dimension;
    Circle(double Dimension )
    {
        super(Dimension);
    }
    double Area()
    {
        System.out.println("Area of the Circle is ");
        return 3.14*Radius*Radius;
    }
    double Circumference()
    {
        System.out.println("Circumference of the Circle is ");
        return 2*3.14*Radius;
    }        
}
class Square extends Shapes
{
    double Side=Dimension;
    Square(double Dimension )
    {
        super(Dimension);
    }
    double Area()
    {
        System.out.println("Area of the Square is ");
        return Side*Side;
    }
    double DiagonalLength()
    {
        System.out.println("Length of the Square is ");
        return 2*(Math.pow(Side,1/2));
    }        
}
class Sphere extends Shapes
{
    double radius=Dimension;
    Sphere (double Dimension )
    {
        super(Dimension);
    }
    double SurfaceArea()
    {
        System.out.println("SurfaceArea of the Sphere is ");
        return 4*3.14*radius*radius;
    }
    double Volume()
    {
        System.out.println("Volume of the Sphere is ");
        return (4/3)*3.14*radius*radius*radius;
    }        
}

public class NewMain
{
    public static void main(String[] args) 
    {
     Circle c=new Circle(5.0);
     System.out.println(+c.Area());
     System.out.println(c.Circumference());
     Square s=new Square(5.0);
     System.out.println(+s.Area());
     System.out.println(+s.DiagonalLength());
     Sphere sp=new Sphere(5.0);
     System.out.println(+sp.SurfaceArea());
     System.out.println(+sp.Volume()); 
    }
    
}
